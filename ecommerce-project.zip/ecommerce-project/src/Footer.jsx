import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <h2>© 2025 MithraShop. All rights reserved.</h2>
      <p>Designed by Sumithra </p>
    </footer>
  );
}

export default Footer;